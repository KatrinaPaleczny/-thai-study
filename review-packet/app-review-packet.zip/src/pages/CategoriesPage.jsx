export function CategoriesPage({ allVocab, cats, goStudy, goCat }) {
  return (
    <div className="page">
      <div className="ph"><div className="ph-t">Categories</div><div className="ph-s">{cats.length} categories</div></div>
      <div className="cat-grid">
        {cats.map(cat=>{
          const words = allVocab.filter(v=>v.category===cat);
          const emojis = [...new Set(words.map(v=>v.emoji).filter(Boolean))].slice(0,3).join(" ");
          return (
            <div key={cat} className="cat-card" onClick={()=>goCat(cat)}>
              <div className="cat-ej">{emojis||"📝"}</div>
              <div className="cat-tt">{cat}</div>
              <div className="cat-ct">{words.length} words</div>
              <div className="cat-acts">
                <button className="btn btn-sec btn-sm" onClick={e=>{e.stopPropagation();goCat(cat)}}>Browse</button>
                <button className="btn btn-pri btn-sm" onClick={e=>{e.stopPropagation();goStudy(cat)}}>Study</button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
