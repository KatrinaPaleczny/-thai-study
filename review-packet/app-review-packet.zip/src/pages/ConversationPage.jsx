import { useState } from "react";
import { SCENARIOS_DATA } from "../data/scenariosData";
import { PlusIcon, XIcon } from "../components/Icons";
import { loadLS, saveLS, K_CONV, K_CONV_CUSTOM } from "../utils/storage";

function AddScenarioModal({ onSave, onClose }) {
  const [title, setTitle] = useState("");
  const [goal, setGoal] = useState("");
  const [turns, setTurns] = useState([{role:"You",prompt_en:"",thai_hint:""}]);
  const addTurn = () => setTurns(t=>[...t,{role:"You",prompt_en:"",thai_hint:""}]);
  const setTurn = (i,k,v) => setTurns(t=>t.map((x,j)=>j===i?{...x,[k]:v}:x));
  const delTurn = i => setTurns(t=>t.filter((_,j)=>j!==i));
  const valid = title.trim() && turns.length>0;
  return (
    <div className="modal-overlay" onClick={e=>e.target===e.currentTarget&&onClose()}>
      <div className="modal" style={{maxWidth:540}}>
        <div className="modal-t">Add Scenario</div>
        <div className="modal-s">Add a conversation from your tutor session</div>
        <div className="field"><label>Title *</label>
          <input placeholder="e.g. At the Coffee Shop ☕" value={title} onChange={e=>setTitle(e.target.value)}/></div>
        <div className="field"><label>Goal / context</label>
          <input placeholder="e.g. Order coffee and ask about specials" value={goal} onChange={e=>setGoal(e.target.value)}/></div>
        <div style={{fontSize:11.5,fontWeight:500,color:"var(--t2)",marginBottom:8}}>Turns</div>
        {turns.map((t,i)=>(
          <div key={i} className="turn-row">
            <div style={{flex:1}}>
              <div style={{display:"grid",gridTemplateColumns:"90px 1fr",gap:6,marginBottom:4}}>
                <select value={t.role} onChange={e=>setTurn(i,"role",e.target.value)}
                  style={{padding:"6px 8px",border:"1px solid var(--bdr)",borderRadius:6,fontSize:12,background:"var(--sur)",color:"var(--t1)"}}>
                  <option>You</option><option>Teacher</option><option>Friend</option>
                </select>
                <input placeholder="What happens in English" value={t.prompt_en} onChange={e=>setTurn(i,"prompt_en",e.target.value)}
                  style={{padding:"6px 10px",border:"1px solid var(--bdr)",borderRadius:6,fontSize:12}}/>
              </div>
              <input placeholder="Thai hint / phonetics" value={t.thai_hint} onChange={e=>setTurn(i,"thai_hint",e.target.value)}
                style={{width:"100%",padding:"6px 10px",border:"1px solid var(--bdr)",borderRadius:6,fontSize:12,fontFamily:"var(--thai)"}}/>
            </div>
            <button className="turn-del" onClick={()=>delTurn(i)}><XIcon/></button>
          </div>
        ))}
        <button className="btn btn-sec btn-sm" style={{marginTop:8}} onClick={addTurn}><PlusIcon/> Add turn</button>
        <div className="modal-btns">
          <button className="modal-btn sec" onClick={onClose}>Cancel</button>
          <button className="modal-btn prim" onClick={()=>valid&&onSave({title,goal,turns})} style={{opacity:valid?1:0.5}}>Save</button>
        </div>
      </div>
    </div>
  );
}

export function ConversationPage() {
  const [selected, setSelected] = useState(null);
  const [revealed, setRevealed] = useState(new Set());
  const [doneSet, setDoneSet] = useState(()=>new Set(loadLS(K_CONV,[])));
  const [customScenarios, setCustomScenarios] = useState(()=>loadLS(K_CONV_CUSTOM,[]));
  const [showAdd, setShowAdd] = useState(false);
  const all = [...SCENARIOS_DATA, ...customScenarios];

  const toggleDone = i => setDoneSet(prev=>{
    const n=new Set(prev); n.has(i)?n.delete(i):n.add(i);
    saveLS(K_CONV,[...n]); return n;
  });
  const toggleReveal = key => setRevealed(prev=>{const n=new Set(prev);n.has(key)?n.delete(key):n.add(key);return n;});

  if (selected!==null) {
    const sc = all[selected];
    return (
      <div className="page">
        <button className="back-btn" onClick={()=>{setSelected(null);setRevealed(new Set());}}>← Back</button>
        <div className="ph-t" style={{marginBottom:4}}>{sc.title}</div>
        <div className="ph-s" style={{marginBottom:16}}>{sc.goal}</div>
        <div style={{display:"flex",gap:8,marginBottom:20,flexWrap:"wrap"}}>
          <button className="btn btn-sec btn-sm" onClick={()=>setRevealed(new Set(sc.turns.map((_,i)=>i)))}>Reveal all hints</button>
          <button className="btn btn-sec btn-sm" onClick={()=>setRevealed(new Set())}>Hide all</button>
          <button className={`conv-done-btn ${doneSet.has(selected)?"unmark":"mark"}`} onClick={()=>toggleDone(selected)}>
            {doneSet.has(selected)?"✓ Mark incomplete":"Mark as done ✓"}
          </button>
        </div>
        <div className="conv-scene">
          {sc.turns.map((turn,i)=>(
            <div key={i} className="conv-turn">
              <div className={`conv-role${turn.role==="You"?" you":""}`}>{turn.role}</div>
              <div className="conv-bub">
                <div className="conv-pr">{turn.prompt_en}</div>
                {revealed.has(i)
                  ? <div className="conv-hint">{turn.thai_hint}</div>
                  : <button className="conv-rb" onClick={()=>toggleReveal(i)}>Show {turn.role==="You"?"hint":"Thai"}</button>}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="ph" style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between"}}>
        <div><div className="ph-t">Conversation Practice</div>
          <div className="ph-s">{all.length} scenarios · {[...doneSet].filter(i=>i<all.length).length} completed</div></div>
        <button className="btn btn-pri" onClick={()=>setShowAdd(true)}><PlusIcon/> Add scenario</button>
      </div>
      <div className="conv-list">
        {all.map((sc,i)=>(
          <div key={i} className={`conv-card${doneSet.has(i)?" done":""}`} onClick={()=>setSelected(i)}>
            <div className="conv-tt">{sc.title}</div>
            <div className="conv-goal">{sc.goal}</div>
            <div className="conv-meta">
              {doneSet.has(i)&&<span className="conv-badge done">✓ Done</span>}
              <span className="conv-badge cnt">{sc.turns.length} turns</span>
              {i>=SCENARIOS_DATA.length&&<span className="conv-badge cnt" style={{background:"var(--abg)",color:"var(--amber)"}}>Custom</span>}
            </div>
          </div>
        ))}
      </div>
      {showAdd && <AddScenarioModal onSave={sc=>{
        const up=[...customScenarios,sc]; setCustomScenarios(up); saveLS(K_CONV_CUSTOM,up); setShowAdd(false);
      }} onClose={()=>setShowAdd(false)}/>}
    </div>
  );
}
