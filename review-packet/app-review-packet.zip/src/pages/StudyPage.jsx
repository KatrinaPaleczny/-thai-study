import { useState } from "react";

export function StudyPage({ allVocab, studyCat, studied, toggleStudied, onBack }) {
  const deck = studyCat ? allVocab.filter(v=>v.category===studyCat) : allVocab;
  const [idx, setIdx] = useState(0);
  const [revealed, setRevealed] = useState(false);
  if (!deck.length) return <div className="page"><button className="back-btn" onClick={onBack}>← Back</button><div className="empty">No cards.</div></div>;
  const card = deck[idx%deck.length];
  const go = (dir, mark=false) => {
    if (mark && !studied.has(card.id)) toggleStudied(card.id);
    setIdx(i=>(i+dir+deck.length)%deck.length); setRevealed(false);
  };
  return (
    <div className="page">
      <button className="back-btn" onClick={onBack}>← Back</button>
      <div className="ph-t" style={{marginBottom:4}}>{studyCat||"All Words"}</div>
      <div className="ph-s" style={{marginBottom:20}}>{deck.length} cards</div>
      <div className="fc-wrap">
        <div className="fc-prog">{(idx%deck.length)+1} / {deck.length}</div>
        <div className="fc" onClick={()=>!revealed&&setRevealed(true)}>
          <div className="fc-cat">{card.category}</div>
          <div className="fc-ej">{card.emoji}</div>
          <div className="fc-front-ph">{card.phonetics}</div>
          {!revealed && <div className="fc-front-lbl">Tap to reveal Thai</div>}
          {revealed && <div className="fc-rev">
            <div className="fc-thai">{card.thai}</div>
            <div className="fc-en">{card.english}</div>
          </div>}
        </div>
        {revealed && card.example_thai && (
          <div className="fc-ex"><div className="fc-ex-in">
            <div className="fc-ex-lbl">Example</div>
            <div className="fc-ex-th">{card.example_thai}</div>
            {card.example_phonetics && <div className="fc-ex-ph">{card.example_phonetics}</div>}
            {card.example_english && <div className="fc-ex-en">{card.example_english}</div>}
          </div></div>
        )}
        <div className="fc-btns">
          <button className="fc-btn nav" onClick={()=>go(-1)}>←</button>
          {revealed
            ? <><button className="fc-btn rev" onClick={()=>go(1,false)}>Review again</button>
               <button className="fc-btn easy" onClick={()=>go(1,true)}>Got it ✓</button></>
            : <button className="fc-btn easy" onClick={()=>setRevealed(true)}>Reveal</button>}
          <button className="fc-btn nav" onClick={()=>go(1)}>→</button>
        </div>
      </div>
    </div>
  );
}
