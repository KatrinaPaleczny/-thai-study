import { useState, useRef } from "react";
import { NUMBERS_DATA } from "../data/numbersData";

export function NumbersPage() {
  const [tab, setTab] = useState("reference");
  const [dir, setDir] = useState("num-to-thai");
  const [drillIdx, setDrillIdx] = useState(()=>Math.floor(Math.random()*NUMBERS_DATA.length));
  const [input, setInput] = useState("");
  const [result, setResult] = useState(null);
  const [qfIdx, setQfIdx] = useState(()=>Math.floor(Math.random()*NUMBERS_DATA.length));
  const [qfRevealed, setQfRevealed] = useState(false);
  const [streak, setStreak] = useState(0);
  const inpRef = useRef();

  const curr = NUMBERS_DATA[drillIdx];
  const qfCurr = NUMBERS_DATA[qfIdx];

  const check = () => {
    if (!input.trim()) return;
    const ok = dir==="num-to-thai" ? input.trim()===curr.thai : parseInt(input.trim())===curr.value;
    setResult(ok?"ok":"no");
  };
  const nextDrill = () => { setDrillIdx(Math.floor(Math.random()*NUMBERS_DATA.length)); setInput(""); setResult(null); setTimeout(()=>inpRef.current?.focus(),50); };
  const qfNext = () => { setQfIdx(Math.floor(Math.random()*NUMBERS_DATA.length)); setQfRevealed(false); };

  return (
    <div className="page">
      <div className="ph"><div className="ph-t">ตัวเลข — Numbers</div></div>
      <div className="tabs">
        {[["reference","Reference"],["drill","Type Drill"],["quickfire","⚡ Quick Fire"]].map(([k,l])=>
          <button key={k} className={`tab${tab===k?" on":""}`} onClick={()=>setTab(k)}>{l}</button>)}
      </div>
      {tab==="reference" && (
        <div className="num-grid">
          {NUMBERS_DATA.map(n=>(
            <div key={n.value} className="num-card">
              <div className="num-val">{n.value}</div>
              <div className="num-th">{n.thai}</div>
              <div className="num-ph">{n.phonetics}</div>
            </div>
          ))}
        </div>
      )}
      {tab==="drill" && (
        <div className="num-drill">
          <div style={{display:"flex",gap:6,marginBottom:16,justifyContent:"center"}}>
            {[["num-to-thai","Number → Thai"],["thai-to-num","Thai → Number"]].map(([k,l])=>
              <button key={k} className={`vt-btn${dir===k?" on":""}`} onClick={()=>{setDir(k);setInput("");setResult(null);}}>{l}</button>)}
          </div>
          <div className="num-q">
            <div className="num-ql">{dir==="num-to-thai"?"Type the Thai word for:":"What number is this?"}</div>
            {dir==="num-to-thai"
              ? <div className="num-disp">{curr.value}</div>
              : <div><div className="num-qf-thai">{curr.thai}</div><div style={{fontSize:13,color:"var(--t3)"}}>{curr.phonetics}</div></div>}
            {result && <div className={`num-res ${result}`}>{result==="ok"?"✓ Correct!":`✗ Answer: ${dir==="num-to-thai"?curr.thai:curr.value}`}</div>}
          </div>
          <input ref={inpRef} className="num-inp" placeholder={dir==="num-to-thai"?"Thai word…":"Number…"}
            value={input} onChange={e=>setInput(e.target.value)}
            onKeyDown={e=>{if(e.key==="Enter"){result?nextDrill():check();}}}/>
          <div style={{display:"flex",gap:8,justifyContent:"center"}}>
            {!result ? <button className="num-b p" onClick={check}>Check</button>
              : <button className="num-b p" onClick={nextDrill}>Next →</button>}
            <button className="num-b s" onClick={nextDrill}>Skip</button>
          </div>
        </div>
      )}
      {tab==="quickfire" && (
        <div className="num-drill">
          <div style={{marginBottom:8,fontSize:12,color:"var(--t2)",textAlign:"center"}}>No typing — just tap Got it or Missed it. Build speed recognition.</div>
          <div style={{display:"flex",gap:6,marginBottom:16,justifyContent:"center"}}>
            {[["num-to-thai","Number → Thai"],["thai-to-num","Thai → Number"]].map(([k,l])=>
              <button key={k} className={`vt-btn${dir===k?" on":""}`} onClick={()=>{setDir(k);setQfRevealed(false);setStreak(0);}}>{l}</button>)}
          </div>
          <div className="num-q">
            <div className="num-ql">{dir==="num-to-thai"?"What is this in Thai?":"What number is this?"}</div>
            {dir==="num-to-thai"
              ? <div className="num-disp">{qfCurr.value}</div>
              : <div><div className="num-qf-thai">{qfCurr.thai}</div><div style={{fontSize:13,color:"var(--t3)"}}>{qfCurr.phonetics}</div></div>}
            {qfRevealed && (
              <div style={{marginTop:12,padding:"10px 14px",background:"var(--tbg)",borderRadius:8}}>
                <div style={{fontFamily:"var(--thai)",fontSize:20}}>{qfCurr.thai}</div>
                <div style={{fontSize:12,color:"var(--t3)"}}>{qfCurr.phonetics} · {qfCurr.value}</div>
              </div>
            )}
          </div>
          {!qfRevealed
            ? <div style={{textAlign:"center"}}><button className="num-b p" onClick={()=>setQfRevealed(true)}>Reveal</button></div>
            : <div className="qf-btns">
                <button className="qf-btn miss" onClick={()=>{setStreak(0);qfNext();}}>✗ Missed it</button>
                <button className="qf-btn got" onClick={()=>{setStreak(s=>s+1);qfNext();}}>✓ Got it</button>
              </div>}
          <div className="qf-streak">Streak: <strong>{streak}</strong></div>
        </div>
      )}
    </div>
  );
}
