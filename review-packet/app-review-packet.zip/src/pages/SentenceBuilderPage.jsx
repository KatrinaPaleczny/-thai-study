import { useState, useMemo, useEffect, useRef } from "react";
import { SENTENCE_EXERCISES } from "../data/sentenceExercises";

export function SentenceBuilderPage() {
  const [wkFilter, setWkFilter] = useState("All");
  const [pool, setPool] = useState(()=>[...SENTENCE_EXERCISES].sort(()=>Math.random()-.5));
  const [idx, setIdx] = useState(0);
  const [input, setInput] = useState("");
  const [revealed, setRevealed] = useState(false);
  const [score, setScore] = useState({c:0,t:0});
  const inpRef = useRef();

  const filtered = useMemo(()=>{
    if (wkFilter==="All") return SENTENCE_EXERCISES;
    return SENTENCE_EXERCISES.filter(e=>e.week===parseInt(wkFilter.replace("Week ","")));
  },[wkFilter]);

  useEffect(()=>{
    const shuffled=[...filtered].sort(()=>Math.random()-.5);
    setPool(shuffled); setIdx(0); setInput(""); setRevealed(false);
  },[filtered]);

  const current = pool[idx%Math.max(pool.length,1)];
  if (!current) return <div className="page"><div className="empty">No exercises yet.</div></div>;

  const isCorrect = input.trim().replace(/\s+/g,"")===current.thai.replace(/\s+/g,"");

  const check = () => {
    if (!input.trim()) return;
    setRevealed(true);
    setScore(s=>({c:s.c+(isCorrect?1:0),t:s.t+1}));
  };
  const next = () => {
    setIdx(i=>(i+1)%pool.length); setInput(""); setRevealed(false);
    setTimeout(()=>inpRef.current?.focus(),50);
  };

  return (
    <div className="page">
      <div className="ph"><div className="ph-t">Sentence Builder</div>
        <div className="ph-s">English → Thai · practice producing sentences, not just recognising them</div></div>
      <div className="wk-tabs">
        {["All","Week 1","Week 2","Week 3","Week 4"].map(w=>
          <button key={w} className={`wk-tab${wkFilter===w?" on":""}`} onClick={()=>setWkFilter(w)}>{w}</button>)}
      </div>
      {score.t>0 && <div className="sb-score">
        <div>Correct: <b style={{color:"var(--teal)"}}>{score.c}</b></div>
        <div>Total: <b>{score.t}</b></div>
        <div>Rate: <b>{Math.round(score.c/score.t*100)}%</b></div>
      </div>}
      <div className="sb-page">
        <div className="sb-q">
          <div className="sb-pattern">Pattern: {current.pattern}</div>
          <div style={{fontSize:10,color:"var(--t3)",marginBottom:12}}>Week {current.week} · {idx%pool.length+1}/{pool.length}</div>
          <div className="sb-english">"{current.english}"</div>
          <div className="sb-hint">Hint: {current.hint}</div>
        </div>
        <input ref={inpRef}
          className={`sb-inp${revealed?(isCorrect?" correct":" wrong"):""}`}
          placeholder="Type the Thai sentence…"
          value={input}
          onChange={e=>setInput(e.target.value)}
          onKeyDown={e=>{if(e.key==="Enter"){revealed?next():check();}}}
          disabled={revealed}
          style={{fontFamily:"var(--thai)"}}
        />
        {revealed && (
          <div className={`sb-result ${isCorrect?"ok":"no"}`}>
            <div className="sb-result-th">{current.thai}</div>
            <div className="sb-result-ph">{current.phonetics}</div>
            <div className="sb-result-tip">💡 {current.tip}</div>
          </div>
        )}
        <div className="sb-btns">
          {!revealed
            ? <><button className="sb-act-btn skip" onClick={next}>Skip</button>
               <button className="sb-act-btn check" onClick={check} style={{opacity:input.trim()?1:0.5}}>Check →</button></>
            : <button className="sb-act-btn next" onClick={next}>Next →</button>}
        </div>
      </div>
    </div>
  );
}
