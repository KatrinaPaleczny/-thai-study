import { GRAMMAR_DATA } from "../data/grammarData";
import { SENTENCE_EXERCISES } from "../data/sentenceExercises";
import { SCENARIOS_DATA } from "../data/scenariosData";

// Local-calendar-day seed — changes at local midnight, not UTC midnight.
// Uses noon to avoid any DST edge cases (DST transitions never happen at noon).
function getLocalDaySeed() {
  const now = new Date();
  const noon = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 12, 0, 0);
  const epoch = new Date(2025, 0, 1, 12, 0, 0); // Jan 1 2025 local time
  return Math.floor((noon - epoch) / 86400000);
}

const daySeed   = getLocalDaySeed();
const isDeepDay = [3, 6].includes(new Date().getDay()); // Wed=3, Sat=6

const grammarOfDay  = GRAMMAR_DATA[daySeed % GRAMMAR_DATA.length];
const sentenceOfDay = SENTENCE_EXERCISES[daySeed % SENTENCE_EXERCISES.length];
const scenarioOfDay = SCENARIOS_DATA[daySeed % SCENARIOS_DATA.length];

export function Dashboard({ allVocab, favs, studied, pinned, cats, goStudy, setPage }) {
  // 5 daily vocab words spread evenly across the list (37 and 150 are coprime → always distinct)
  const dailyWords = [0, 1, 2, 3, 4].map(i => allVocab[(daySeed + i * 37) % allVocab.length]);

  return (
    <div className="page">
      <div className="ph">
        <div className="ph-t">สวัสดีค่ะ คุณแคท 👋</div>
        <div className="ph-s">Your Thai study hub</div>
      </div>

      {/* ── Today's study ── */}
      <div style={{marginBottom:28}}>

        {/* Day type label */}
        <div style={{display:"flex",alignItems:"center",gap:8,marginBottom:14}}>
          <div className="sec-t" style={{margin:0}}>Today's study</div>
          <span style={{
            fontSize:11,fontWeight:500,padding:"2px 9px",borderRadius:20,
            background:isDeepDay?"var(--walnut-soft)":"var(--olive-soft)",
            color:isDeepDay?"var(--walnut)":"var(--olive)",
            border:`1px solid ${isDeepDay?"#c9967a":"var(--olive-mid)"}`,
          }}>
            {isDeepDay ? "Deep study day · grammar & vocab" : "15-min daily review"}
          </span>
        </div>

        {isDeepDay && (
          <div style={{fontSize:12,color:"var(--t2)",marginBottom:14,padding:"9px 12px",background:"var(--walnut-soft)",borderRadius:8,border:"1px solid #c9967a"}}>
            Today is a good day to spend a little extra time in Grammar and Vocabulary.
          </div>
        )}

        {/* 5 daily words */}
        <div style={{marginBottom:18}}>
          <div style={{fontSize:11.5,fontWeight:500,color:"var(--t2)",marginBottom:8}}>5 words to review today</div>
          <div className="rec-grid">
            {dailyWords.map((v,i) => (
              <div key={i} className="rec-card">
                <div className="rec-th">{v.thai}</div>
                <div className="rec-ph">{v.phonetics}</div>
                <div className="rec-en">{v.english}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Grammar of the day */}
        <div style={{marginBottom:14}}>
          <div style={{fontSize:11.5,fontWeight:500,color:"var(--t2)",marginBottom:8}}>Grammar of the day</div>
          <div style={{background:"var(--sur)",border:"1px solid var(--bdr)",borderRadius:10,padding:"13px 15px"}}>
            <div style={{display:"flex",alignItems:"center",gap:9,marginBottom:8}}>
              <span style={{fontSize:16}}>{grammarOfDay.icon}</span>
              <span style={{fontFamily:"var(--disp)",fontSize:14,fontWeight:500,flex:1}}>{grammarOfDay.title}</span>
              <span style={{fontSize:9.5,color:"var(--t3)",border:"1px solid var(--bdr)",padding:"2px 7px",borderRadius:7,whiteSpace:"nowrap"}}>{grammarOfDay.level}</span>
            </div>
            <div style={{fontSize:12,color:"var(--t2)",marginBottom:9}}>{grammarOfDay.summary}</div>
            {grammarOfDay.examples[0] && (
              <div style={{background:"var(--sur2)",borderRadius:7,padding:"8px 11px",marginBottom:10}}>
                <div style={{fontFamily:"var(--thai)",fontSize:15,marginBottom:2}}>{grammarOfDay.examples[0].thai}</div>
                <div style={{fontSize:11,color:"var(--t3)",fontStyle:"italic",marginBottom:2}}>{grammarOfDay.examples[0].phonetics}</div>
                <div style={{fontSize:11.5,color:"var(--t2)"}}>{grammarOfDay.examples[0].english}</div>
              </div>
            )}
            <button className="btn btn-sec btn-sm" onClick={()=>setPage("grammar")}>See all grammar →</button>
          </div>
        </div>

        {/* Sentence prompt of the day */}
        <div style={{marginBottom:14}}>
          <div style={{fontSize:11.5,fontWeight:500,color:"var(--t2)",marginBottom:8}}>Sentence to try today</div>
          <div style={{background:"var(--sur)",border:"1px solid var(--bdr)",borderRadius:10,padding:"13px 15px"}}>
            <div style={{fontSize:10,color:"var(--t3)",letterSpacing:".07em",textTransform:"uppercase",marginBottom:6}}>Pattern: {sentenceOfDay.pattern}</div>
            <div style={{fontFamily:"var(--disp)",fontSize:18,fontWeight:500,marginBottom:6}}>"{sentenceOfDay.english}"</div>
            <div style={{fontSize:12,color:"var(--t3)",fontStyle:"italic",marginBottom:10}}>Hint: {sentenceOfDay.hint}</div>
            <button className="btn btn-pri btn-sm" onClick={()=>setPage("builder")}>Practice in Sentence Builder →</button>
          </div>
        </div>

        {/* Conversation to revisit */}
        <div>
          <div style={{fontSize:11.5,fontWeight:500,color:"var(--t2)",marginBottom:8}}>Conversation to revisit</div>
          <div style={{background:"var(--sur)",border:"1px solid var(--bdr)",borderRadius:10,padding:"13px 15px",display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:12}}>
            <div>
              <div style={{fontFamily:"var(--disp)",fontSize:14,fontWeight:500,marginBottom:3}}>{scenarioOfDay.title}</div>
              <div style={{fontSize:12,color:"var(--t2)"}}>{scenarioOfDay.goal}</div>
            </div>
            <button className="btn btn-sec btn-sm" style={{flexShrink:0}} onClick={()=>setPage("conversation")}>Open →</button>
          </div>
        </div>
      </div>

      {/* ── Existing sections — unchanged ── */}

      <div className="stats">
        <div className="stat"><div className="stat-n">{allVocab.length}</div><div className="stat-l">Total words</div></div>
        <div className="stat"><div className="stat-n">{studied.size}</div><div className="stat-l">Studied</div></div>
        <div className="stat"><div className="stat-n">{favs.size}</div><div className="stat-l">Favourites</div></div>
        <div className="stat"><div className="stat-n">{pinned.size}</div><div className="stat-l">Pinned this week</div></div>
      </div>

      <div style={{marginBottom:16}}>
        <div className="sec-t">Quick study</div>
        <button className="ql-btn" onClick={()=>goStudy(null)}>📚 All words</button>
        {cats.slice(0,8).map(c=><button key={c} className="ql-btn" onClick={()=>goStudy(c)}>{c}</button>)}
      </div>

      <div style={{marginBottom:16}}>
        <div className="sec-t">Tools</div>
        <button className="ql-btn" onClick={()=>setPage("grammar")}>📐 Grammar</button>
        <button className="ql-btn" onClick={()=>setPage("numbers")}>🔢 Numbers</button>
        <button className="ql-btn" onClick={()=>setPage("conversation")}>💬 Conversation</button>
        <button className="ql-btn" onClick={()=>setPage("builder")}>✍️ Sentence Builder</button>
      </div>

      <div className="dash2">
        <div>
          <div className="sec-t">Recently studied</div>
          <div className="rec-grid">
            {allVocab.filter(v=>studied.has(v.id)).slice(-6).reverse().map(v=>(
              <div key={v.id} className="rec-card">
                <div className="rec-th">{v.thai}</div><div className="rec-ph">{v.phonetics}</div><div className="rec-en">{v.english}</div>
              </div>
            ))}
          </div>
        </div>
        <div>
          <div className="sec-t">Favourites</div>
          <div className="rec-grid">
            {allVocab.filter(v=>favs.has(v.id)).slice(0,6).map(v=>(
              <div key={v.id} className="rec-card">
                <div className="rec-th">{v.thai}</div><div className="rec-ph">{v.phonetics}</div><div className="rec-en">{v.english}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
