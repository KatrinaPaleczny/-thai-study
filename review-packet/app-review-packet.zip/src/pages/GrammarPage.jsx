import { useState } from "react";
import { GRAMMAR_DATA } from "../data/grammarData";
import { ChevD } from "../components/Icons";

export function GrammarPage() {
  const [open, setOpen] = useState(null);
  const [wk, setWk] = useState("All");
  const shown = GRAMMAR_DATA.filter(g=>wk==="All"||g.level===wk);
  return (
    <div className="page">
      <div className="ph"><div className="ph-t">Grammar Reference</div>
        <div className="ph-s">{GRAMMAR_DATA.length} patterns · click to expand</div></div>
      <div className="wk-tabs">
        {["All","Beginner","Intermediate"].map(w=>
          <button key={w} className={`wk-tab${wk===w?" on":""}`} onClick={()=>{setWk(w);setOpen(null);}}>{w}</button>)}
      </div>
      <div className="gram-list">
        {shown.map(g=>(
          <div key={g.id} className="gram-card">
            <div className="gram-hdr" onClick={()=>setOpen(open===g.id?null:g.id)}>
              <span className="gram-ic">{g.icon}</span>
              <span className="gram-tt">{g.title}</span>
              <span className="gram-lv">{g.level}</span>
              <ChevD/>
            </div>
            {open===g.id && (
              <div className="gram-body">
                <div className="gram-sum">{g.summary}</div>
                {g.formula && (
                  <div style={{fontFamily:"var(--body)",fontSize:13,fontWeight:500,color:"var(--olive)",background:"var(--olive-soft)",border:"1px solid var(--olive-mid)",borderRadius:7,padding:"7px 12px",marginBottom:12,letterSpacing:".01em"}}>
                    {g.formula}
                  </div>
                )}
                <div className="gram-exs">
                  {g.examples.map((ex,i)=>(
                    <div key={i} className="gram-ex">
                      <div className="gram-ex-th">{ex.thai}</div>
                      <div className="gram-ex-ph">{ex.phonetics}</div>
                      <div className="gram-ex-en">{ex.english}</div>
                    </div>
                  ))}
                </div>
                {g.notes && <div className="gram-note">💡 {g.notes}</div>}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
