export function Sidebar({ page, setPage }) {
  const btn = (p,ic,label) => (
    <button className={`sb-btn${page===p?" on":""}`} onClick={()=>setPage(p)}>
      <span className="sb-ic">{ic}</span><span>{label}</span>
    </button>
  );
  return (
    <div className="sb">
      <div className="sb-logo">
        <div className="sb-th">เรียนไทย</div>
        <div className="sb-sub">คุณแคท · Thai Study</div>
      </div>
      <div className="sb-lbl">Learn</div>
      {btn("dashboard","🏠","Dashboard")}
      {btn("vocab","📖","Vocabulary")}
      {btn("study","🃏","Flashcards")}
      {btn("categories","🗂️","Categories")}
      <div className="sb-lbl">Practice</div>
      {btn("conversation","💬","Conversation")}
      {btn("builder","✍️","Sentence Builder")}
      <div className="sb-lbl">Reference</div>
      {btn("grammar","📐","Grammar")}
      {btn("numbers","🔢","Numbers")}
    </div>
  );
}
