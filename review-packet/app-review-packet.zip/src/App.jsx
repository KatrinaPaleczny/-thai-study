import { useState, useMemo } from "react";
import { CSS } from "./appStyles";
import { VOCAB_DATA } from "./data/vocabData";
import { loadLS, useLocalSet, K_FAV, K_STU, K_CUSTOM, K_PINNED } from "./utils/storage";
import { Sidebar } from "./components/Sidebar";
import { Dashboard } from "./pages/Dashboard";
import { VocabPage } from "./pages/VocabPage";
import { StudyPage } from "./pages/StudyPage";
import { CategoriesPage } from "./pages/CategoriesPage";
import { GrammarPage } from "./pages/GrammarPage";
import { NumbersPage } from "./pages/NumbersPage";
import { ConversationPage } from "./pages/ConversationPage";
import { SentenceBuilderPage } from "./pages/SentenceBuilderPage";

export default function App() {
  const [page, setPage] = useState("dashboard");
  const [studyCat, setStudyCat] = useState(null);
  const [favs, toggleFav] = useLocalSet(K_FAV);
  const [studied, toggleStudied] = useLocalSet(K_STU);
  const [pinned, togglePin] = useLocalSet(K_PINNED);
  const [customWords, setCustomWords] = useState(()=>loadLS(K_CUSTOM,[]));

  const allVocab = useMemo(()=>[...VOCAB_DATA,...customWords],[customWords]);
  const cats = useMemo(()=>[...new Set(allVocab.map(v=>v.category))].sort(),[allVocab]);

  const goStudy = (cat=null) => { setStudyCat(cat); setPage("study"); };
  const goCat = () => setPage("vocab");

  const renderPage = () => {
    switch(page) {
      case "dashboard": return <Dashboard allVocab={allVocab} favs={favs} studied={studied} pinned={pinned} cats={cats} goStudy={goStudy} setPage={setPage}/>;
      case "vocab": return <VocabPage allVocab={allVocab} customWords={customWords} setCustomWords={setCustomWords} cats={cats} favs={favs} toggleFav={toggleFav} studied={studied} toggleStudied={toggleStudied} pinned={pinned} togglePin={togglePin}/>;
      case "study": return <StudyPage allVocab={allVocab} studyCat={studyCat} studied={studied} toggleStudied={toggleStudied} onBack={()=>setPage("vocab")}/>;
      case "categories": return <CategoriesPage allVocab={allVocab} cats={cats} goStudy={goStudy} goCat={goCat}/>;
      case "grammar": return <GrammarPage/>;
      case "numbers": return <NumbersPage/>;
      case "conversation": return <ConversationPage/>;
      case "builder": return <SentenceBuilderPage/>;
      default: return <div className="page"><div className="empty">Coming soon</div></div>;
    }
  };

  return (
    <>
      <style>{CSS}</style>
      <div className="app">
        <Sidebar page={page} setPage={setPage}/>
        <div className="main">{renderPage()}</div>
      </div>
    </>
  );
}
