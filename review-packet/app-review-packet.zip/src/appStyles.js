export const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Lora:ital,wght@0,400;0,500;0,600;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&family=Noto+Sans+Thai:wght@300;400;500;600&display=swap');
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#f5f1e8;--sur:#fffaf2;--sur2:#f0e8db;--bdr:#ddd0bc;
  --t1:#2f261c;--t2:#6f6253;--t3:#a59683;
  --olive:#66714a;--olive-soft:#e7ecdf;--olive-mid:#b8c2a4;
  --walnut:#8a5a3c;--walnut-soft:#f4e7dc;
  --thai:'Noto Sans Thai',sans-serif;--body:'DM Sans',sans-serif;--disp:'Lora',serif;
}
body{background:var(--bg);color:var(--t1);font-family:var(--body);font-size:14px;line-height:1.5}
button{font-family:var(--body)}
.app{display:flex;min-height:100vh}
.sb{width:212px;min-width:212px;background:var(--sur);border-right:1px solid var(--bdr);display:flex;flex-direction:column;padding:20px 0;position:sticky;top:0;height:100vh;overflow-y:auto}
.sb-logo{padding:0 20px 22px}
.sb-th{font-family:var(--thai);font-size:20px;font-weight:600;color:var(--olive)}
.sb-sub{font-family:var(--disp);font-style:italic;font-size:10px;color:var(--t3);margin-top:2px}
.sb-lbl{font-size:9px;font-weight:600;letter-spacing:.12em;text-transform:uppercase;color:var(--t3);padding:0 20px;margin-bottom:2px;margin-top:10px}
.sb-btn{display:flex;align-items:center;gap:9px;padding:8px 20px;cursor:pointer;font-size:13px;color:var(--t2);border:none;background:none;width:100%;text-align:left;transition:all .15s}
.sb-btn:hover{color:var(--t1);background:var(--sur2)}
.sb-btn.on{color:var(--olive);background:var(--olive-soft);font-weight:500}
.sb-ic{width:16px;text-align:center;font-size:13px}
.main{flex:1;overflow-y:auto}
.page{padding:32px 40px;max-width:1040px}
.ph{margin-bottom:24px}
.ph-t{font-family:var(--disp);font-size:24px;font-weight:500}
.ph-s{font-size:12px;color:var(--t3);margin-top:3px}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:22px}
.stat{background:var(--sur);border:1px solid var(--bdr);border-radius:10px;padding:15px}
.stat-n{font-family:var(--disp);font-size:26px;font-weight:400}
.stat-l{font-size:11px;color:var(--t3);margin-top:1px}
.chip{display:inline-flex;align-items:center;gap:4px;padding:4px 10px;border-radius:20px;font-size:11px;font-weight:500;cursor:pointer;border:1px solid var(--bdr);background:var(--sur);color:var(--t2);transition:all .15s;white-space:nowrap}
.chip:hover{border-color:var(--olive);color:var(--olive)}.chip.on{background:var(--olive);border-color:var(--olive);color:#fff}
.chips{display:flex;flex-wrap:wrap;gap:6px;margin-bottom:16px}
.srch{position:relative;margin-bottom:14px}
.srch input{width:100%;padding:8px 14px 8px 34px;border:1px solid var(--bdr);border-radius:8px;font-size:13px;background:var(--sur);color:var(--t1);outline:none;transition:border .15s}
.srch input:focus{border-color:var(--olive)}.srch input::placeholder{color:var(--t3)}
.srch-ic{position:absolute;left:11px;top:50%;transform:translateY(-50%);color:var(--t3);pointer-events:none}
.vc{background:var(--sur);border:1px solid var(--bdr);border-radius:9px;padding:10px 14px;cursor:pointer;transition:all .15s}
.vc:hover{border-color:var(--olive-mid)}.vc.open{border-color:var(--olive)}
.vc.custom{border-left:3px solid var(--walnut)}.vc.pinned{border-left:3px solid var(--olive)}
.vc-row{display:flex;align-items:center;gap:8px}
.vc-ej{font-size:14px;width:20px;text-align:center;flex-shrink:0}
.vc-ph{font-size:13.5px;font-weight:500;min-width:120px}
.vc-th{font-family:var(--thai);font-size:13px;color:var(--t3);min-width:80px}
.vc-en{font-size:12.5px;color:var(--t2);flex:1}
.vc-cat{font-size:10px;color:var(--t3);padding:2px 6px;border:1px solid var(--bdr);border-radius:7px;white-space:nowrap}
.vc-acts{display:flex;align-items:center;gap:4px;margin-left:auto;flex-shrink:0}
.ic-btn{background:none;border:none;cursor:pointer;color:var(--t3);padding:3px;border-radius:4px;display:flex;align-items:center;transition:color .15s}
.ic-btn:hover{color:var(--t1)}.ic-btn.fav{color:var(--walnut)}.ic-btn.stu{color:var(--olive)}.ic-btn.pin{color:var(--olive)}.ic-btn.del{color:#e57373}
.vc-ex{margin-top:9px;padding-top:9px;border-top:1px solid var(--bdr)}
.vc-ex-th{font-family:var(--thai);font-size:13px;margin-bottom:2px}
.vc-ex-ph{font-size:10.5px;color:var(--t3);font-style:italic;margin-bottom:1px}
.vc-ex-en{font-size:11.5px;color:var(--t2)}
.vocab-list{display:flex;flex-direction:column;gap:5px}
.filter-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}
.filter-ct{font-size:11px;color:var(--t3)}
.vt-btn{padding:4px 10px;border-radius:6px;font-size:11px;font-weight:500;cursor:pointer;border:1px solid var(--bdr);background:var(--sur);color:var(--t2);transition:all .15s}
.vt-btn.on{background:var(--olive);border-color:var(--olive);color:#fff}
.pinned-banner{background:var(--olive-soft);border:1px solid var(--olive-mid);border-radius:9px;padding:11px 14px;margin-bottom:14px;font-size:12px;color:var(--olive)}
.fc-wrap{display:flex;flex-direction:column;align-items:center;padding-top:4px}
.fc-prog{font-size:11px;color:var(--t3);margin-bottom:16px;letter-spacing:.04em}
.fc{width:100%;max-width:480px;min-height:260px;background:var(--sur);border:1px solid var(--bdr);border-radius:16px;display:flex;flex-direction:column;align-items:center;justify-content:center;padding:32px;cursor:pointer;box-shadow:0 2px 12px rgba(0,0,0,.06);position:relative;text-align:center;transition:box-shadow .2s}
.fc:hover{box-shadow:0 4px 22px rgba(0,0,0,.09)}
.fc-cat{font-size:10px;color:var(--t3);letter-spacing:.07em;text-transform:uppercase;margin-bottom:10px}
.fc-ej{font-size:22px;margin-bottom:8px}
.fc-front-ph{font-size:22px;font-weight:500;margin-bottom:4px}
.fc-front-lbl{font-size:10.5px;color:var(--t3)}
.fc-rev{animation:fadeUp .2s ease;width:100%;text-align:center;margin-top:12px}
.fc-rev-ph{font-size:12px;color:var(--t3);font-style:italic;margin-bottom:8px}
.fc-thai{font-family:var(--thai);font-size:42px;font-weight:500;line-height:1.3;margin-bottom:8px}
.fc-en{font-size:17px;color:var(--t2)}
.fc-hint-lbl{font-size:10.5px;color:var(--t3);position:absolute;bottom:12px}
.fc-btns{display:flex;align-items:center;gap:9px;margin-top:18px}
.fc-btn{padding:8px 17px;border-radius:8px;font-size:12px;font-weight:500;cursor:pointer;border:1px solid var(--bdr);transition:all .15s}
.fc-btn.nav{background:var(--sur);color:var(--t2)}.fc-btn.nav:hover{border-color:var(--olive);color:var(--olive)}
.fc-btn.easy{background:var(--olive);color:#fff;border-color:var(--olive)}.fc-btn.easy:hover{opacity:.9}
.fc-btn.rev{background:var(--sur);color:var(--walnut);border-color:var(--walnut)}.fc-btn.rev:hover{background:var(--walnut-soft)}
.fc-ex{margin-top:16px;max-width:480px;width:100%}
.fc-ex-in{background:var(--sur);border:1px solid var(--bdr);border-radius:9px;padding:12px 14px}
.fc-ex-lbl{font-size:10px;color:var(--t3);text-transform:uppercase;letter-spacing:.07em;margin-bottom:6px}
.fc-ex-th{font-family:var(--thai);font-size:14px;margin-bottom:2px}
.fc-ex-ph{font-size:10.5px;color:var(--t3);font-style:italic;margin-bottom:2px}
.fc-ex-en{font-size:11.5px;color:var(--t2)}
.modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:200;display:flex;align-items:center;justify-content:center;padding:20px}
.modal{background:var(--sur);border-radius:14px;padding:26px;width:100%;max-width:420px;box-shadow:0 8px 40px rgba(0,0,0,.18);max-height:90vh;overflow-y:auto}
.modal-t{font-family:var(--disp);font-size:18px;font-weight:500;margin-bottom:4px}
.modal-s{font-size:12px;color:var(--t3);margin-bottom:20px}
.field{margin-bottom:13px}
.field label{display:block;font-size:11.5px;font-weight:500;color:var(--t2);margin-bottom:5px}
.field input,.field select,.field textarea{width:100%;padding:8px 11px;border:1px solid var(--bdr);border-radius:7px;font-size:13px;font-family:var(--body);background:var(--sur);color:var(--t1);outline:none;transition:border .15s;resize:vertical}
.field input:focus,.field select:focus,.field textarea:focus{border-color:var(--olive)}
.field input::placeholder,.field textarea::placeholder{color:var(--t3)}
.modal-btns{display:flex;gap:9px;margin-top:18px;justify-content:flex-end}
.modal-btn{padding:8px 18px;border-radius:8px;font-size:12.5px;font-weight:500;cursor:pointer;transition:all .15s}
.modal-btn.prim{background:var(--olive);color:#fff;border:none}.modal-btn.prim:hover{opacity:.9}
.modal-btn.sec{background:var(--sur);color:var(--t2);border:1px solid var(--bdr)}.modal-btn.sec:hover{border-color:var(--olive);color:var(--olive)}
.cat-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(225px,1fr));gap:12px}
.cat-card{background:var(--sur);border:1px solid var(--bdr);border-radius:10px;padding:17px;cursor:pointer;transition:all .15s}
.cat-card:hover{border-color:var(--olive);box-shadow:0 2px 12px rgba(0,0,0,.06);transform:translateY(-1px)}
.cat-ej{font-size:16px;margin-bottom:8px;letter-spacing:2px}.cat-tt{font-family:var(--disp);font-size:14.5px;font-weight:500;margin-bottom:3px}.cat-ct{font-size:11px;color:var(--t3)}
.cat-acts{display:flex;gap:6px;margin-top:10px}
.gram-list{display:flex;flex-direction:column;gap:7px}
.gram-card{background:var(--sur);border:1px solid var(--bdr);border-radius:10px;overflow:hidden}
.gram-hdr{display:flex;align-items:center;gap:11px;padding:13px 15px;cursor:pointer;transition:background .15s}
.gram-hdr:hover{background:var(--sur2)}
.gram-ic{font-size:16px;width:24px;text-align:center;flex-shrink:0}
.gram-tt{font-family:var(--disp);font-size:14px;font-weight:500;flex:1}
.gram-lv{font-size:9.5px;color:var(--t3);border:1px solid var(--bdr);padding:2px 7px;border-radius:7px;white-space:nowrap}
.gram-body{padding:0 15px 15px;border-top:1px solid var(--bdr)}
.gram-sum{font-size:13px;color:var(--t2);margin:12px 0}
.gram-exs{display:flex;flex-direction:column;gap:8px;margin-bottom:12px}
.gram-ex{background:var(--sur2);border-radius:7px;padding:10px 12px}
.gram-ex-th{font-family:var(--thai);font-size:16px;margin-bottom:2px}
.gram-ex-ph{font-size:11px;color:var(--t3);font-style:italic;margin-bottom:2px}
.gram-ex-en{font-size:12px;color:var(--t2)}
.gram-note{font-size:11.5px;color:var(--olive);background:var(--olive-soft);border-radius:7px;padding:9px 11px}
.num-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(115px,1fr));gap:8px;margin-bottom:20px}
.num-card{background:var(--sur);border:1px solid var(--bdr);border-radius:9px;padding:12px;text-align:center}
.num-val{font-family:var(--disp);font-size:20px;color:var(--t3);margin-bottom:3px}
.num-th{font-family:var(--thai);font-size:18px;margin-bottom:2px}.num-ph{font-size:11px;color:var(--t3);font-style:italic}
.num-drill{max-width:380px;margin:0 auto}
.num-q{background:var(--sur);border:1px solid var(--bdr);border-radius:14px;padding:28px;text-align:center;box-shadow:0 2px 12px rgba(0,0,0,.06);margin-bottom:16px}
.num-ql{font-size:10px;color:var(--t3);text-transform:uppercase;letter-spacing:.07em;margin-bottom:12px}
.num-disp{font-family:var(--disp);font-size:50px;margin-bottom:5px}
.num-qf-thai{font-family:var(--thai);font-size:44px;margin-bottom:5px}
.num-res{margin-top:10px;font-size:13px;padding:7px 12px;border-radius:7px;font-weight:500}
.num-res.ok{background:var(--olive-soft);color:var(--olive)}.num-res.no{background:var(--walnut-soft);color:var(--walnut)}
.num-inp{width:100%;padding:9px 12px;border:1px solid var(--bdr);border-radius:8px;font-size:14px;font-family:var(--thai);outline:none;text-align:center;margin-bottom:9px;background:var(--sur);color:var(--t1)}
.num-inp:focus{border-color:var(--olive)}
.num-b{padding:7px 17px;border-radius:8px;font-size:12px;font-weight:500;cursor:pointer;transition:all .15s}
.num-b.p{background:var(--olive);color:#fff;border:none}.num-b.s{background:var(--sur);color:var(--t2);border:1px solid var(--bdr)}
.qf-btns{display:flex;gap:10px;justify-content:center;margin-top:12px}
.qf-btn{padding:10px 28px;border-radius:10px;font-size:13px;font-weight:500;cursor:pointer;border:none;transition:all .15s}
.qf-btn.got{background:var(--olive);color:#fff}.qf-btn.got:hover{opacity:.9}
.qf-btn.miss{background:var(--sur);color:var(--walnut);border:1px solid var(--walnut)}.qf-btn.miss:hover{background:var(--walnut-soft)}
.qf-streak{font-size:12px;color:var(--t3);margin-top:10px;text-align:center}
.conv-list{display:flex;flex-direction:column;gap:8px}
.conv-card{background:var(--sur);border:1px solid var(--bdr);border-radius:10px;padding:14px 16px;cursor:pointer;transition:all .15s}
.conv-card:hover{border-color:var(--olive-mid)}.conv-card.done{border-color:var(--olive);background:var(--olive-soft)}
.conv-tt{font-family:var(--disp);font-size:14px;font-weight:500;margin-bottom:3px}
.conv-goal{font-size:11.5px;color:var(--t2)}
.conv-meta{display:flex;align-items:center;gap:8px;margin-top:8px}
.conv-badge{font-size:10px;padding:2px 8px;border-radius:6px;font-weight:500}
.conv-badge.done{background:var(--olive);color:#fff}.conv-badge.cnt{background:var(--sur2);color:var(--t3)}
.conv-scene{max-width:580px}
.conv-turn{display:flex;gap:10px;margin-bottom:12px;align-items:flex-start}
.conv-role{font-size:10px;font-weight:600;text-transform:uppercase;letter-spacing:.07em;min-width:48px;padding-top:2px;color:var(--t3)}
.conv-role.you{color:var(--olive)}
.conv-bub{flex:1}
.conv-pr{font-size:13px;color:var(--t2);margin-bottom:4px}
.conv-hint{background:var(--olive-soft);border:1px solid var(--olive-mid);border-radius:7px;padding:6px 10px;font-size:13px;color:var(--olive);display:inline-block}
.conv-rb{font-size:11px;color:var(--t3);border:1px solid var(--bdr);background:none;cursor:pointer;padding:3px 9px;border-radius:5px;transition:all .15s}
.conv-rb:hover{border-color:var(--olive);color:var(--olive)}
.conv-done-btn{padding:7px 16px;border-radius:8px;font-size:12px;font-weight:500;cursor:pointer;transition:all .15s}
.conv-done-btn.mark{background:var(--olive);color:#fff;border:none}.conv-done-btn.unmark{background:var(--sur);color:var(--t2);border:1px solid var(--bdr)}
.turn-row{display:flex;gap:8px;align-items:flex-start;margin-bottom:8px}
.turn-del{background:none;border:none;cursor:pointer;color:var(--t3);padding:4px;border-radius:4px;flex-shrink:0;margin-top:2px}
.turn-del:hover{color:#e57373}
.sb-page{background:var(--sur);border:1px solid var(--bdr);border-radius:14px;padding:28px;max-width:520px;margin:0 auto;box-shadow:0 2px 16px rgba(0,0,0,.06)}
.sb-q{text-align:center;margin-bottom:24px}
.sb-pattern{font-size:10px;color:var(--t3);letter-spacing:.08em;text-transform:uppercase;margin-bottom:6px}
.sb-english{font-size:22px;font-weight:500;font-family:var(--disp);margin-bottom:8px}
.sb-hint{font-size:12px;color:var(--t3);font-style:italic}
.sb-inp{width:100%;padding:11px 14px;border:2px solid var(--bdr);border-radius:10px;font-size:16px;font-family:var(--thai);outline:none;text-align:center;background:var(--sur);color:var(--t1);transition:border .2s;margin-bottom:14px}
.sb-inp:focus{border-color:var(--olive)}.sb-inp.correct{border-color:var(--olive);background:var(--olive-soft)}.sb-inp.wrong{border-color:var(--walnut);background:var(--walnut-soft)}
.sb-result{padding:14px;border-radius:10px;text-align:center;margin-bottom:14px}
.sb-result.ok{background:var(--olive-soft);border:1px solid var(--olive-mid)}.sb-result.no{background:var(--walnut-soft);border:1px solid #c9967a}
.sb-result-th{font-family:var(--thai);font-size:24px;margin-bottom:4px}
.sb-result-ph{font-size:12px;color:var(--t3);font-style:italic;margin-bottom:6px}
.sb-result-tip{font-size:12px;color:var(--t2)}
.sb-btns{display:flex;gap:9px;justify-content:center}
.sb-act-btn{padding:9px 22px;border-radius:9px;font-size:13px;font-weight:500;cursor:pointer;transition:all .15s}
.sb-act-btn.check{background:var(--olive);color:#fff;border:none}.sb-act-btn.check:hover{opacity:.9}
.sb-act-btn.skip{background:var(--sur);color:var(--t2);border:1px solid var(--bdr)}.sb-act-btn.skip:hover{border-color:var(--olive);color:var(--olive)}
.sb-act-btn.next{background:var(--olive);color:#fff;border:none}.sb-act-btn.next:hover{opacity:.9}
.sb-score{display:flex;gap:14px;justify-content:center;font-size:12px;color:var(--t3);margin-bottom:18px}
.sb-score b{color:var(--t1)}
.wk-tabs{display:flex;gap:4px;margin-bottom:18px;flex-wrap:wrap}
.wk-tab{padding:5px 12px;border-radius:20px;font-size:11px;font-weight:500;cursor:pointer;border:1px solid var(--bdr);background:var(--sur);color:var(--t2);transition:all .15s}
.wk-tab:hover{border-color:var(--olive);color:var(--olive)}.wk-tab.on{background:var(--olive);border-color:var(--olive);color:#fff}
.tabs{display:flex;gap:3px;margin-bottom:18px;border-bottom:1px solid var(--bdr)}
.tab{padding:7px 13px;font-size:12.5px;font-weight:500;cursor:pointer;border:none;background:none;color:var(--t2);border-bottom:2px solid transparent;margin-bottom:-1px;transition:all .15s}
.tab:hover{color:var(--t1)}.tab.on{color:var(--olive);border-bottom-color:var(--olive)}
.btn{display:inline-flex;align-items:center;gap:6px;padding:7px 13px;border-radius:8px;font-size:12.5px;font-weight:500;cursor:pointer;transition:all .15s}
.btn-pri{background:var(--olive);color:#fff;border:none}.btn-pri:hover{opacity:.88}
.btn-sec{background:var(--sur);color:var(--t2);border:1px solid var(--bdr)}.btn-sec:hover{border-color:var(--olive);color:var(--olive)}
.btn-sm{padding:5px 10px;font-size:11.5px;border-radius:6px}
.empty{text-align:center;padding:44px;color:var(--t3)}
.sec-gap{margin-top:24px}
.back-btn{font-size:12px;padding:5px 10px;border:1px solid var(--bdr);border-radius:6px;background:none;cursor:pointer;color:var(--t2);transition:all .15s;margin-bottom:18px;display:inline-flex;align-items:center;gap:6px}
.back-btn:hover{border-color:var(--olive);color:var(--olive)}
.dash2{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:20px}
.sec-t{font-family:var(--disp);font-size:14px;font-weight:500;margin-bottom:10px}
.rec-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(165px,1fr));gap:7px;margin-top:16px}
.rec-card{background:var(--sur);border:1px solid var(--bdr);border-radius:9px;padding:10px}
.rec-th{font-family:var(--thai);font-size:18px;margin-bottom:1px}.rec-ph{font-size:10.5px;color:var(--t3);font-style:italic;margin-bottom:2px}.rec-en{font-size:11.5px;color:var(--t2)}
.ql-btn{display:inline-flex;align-items:center;gap:5px;padding:6px 11px;border-radius:7px;font-size:12px;border:1px solid var(--bdr);background:var(--sur);cursor:pointer;color:var(--t2);transition:all .15s;margin:3px}
.ql-btn:hover{border-color:var(--olive);color:var(--olive);background:var(--olive-soft)}
@keyframes fadeUp{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
::-webkit-scrollbar{width:5px}::-webkit-scrollbar-thumb{background:var(--bdr);border-radius:3px}
@media(max-width:820px){
  .sb{width:50px;min-width:50px;padding:12px 0}
  .sb-logo,.sb-lbl,.sb-btn span:not(.sb-ic){display:none}
  .sb-btn{justify-content:center;padding:10px}
  .page{padding:16px 12px}
  .stats{grid-template-columns:repeat(2,1fr)}
  .dash2{grid-template-columns:1fr}
  .fc-thai{font-size:34px}
}
@media(max-width:500px){.vc-cat,.vc-th{display:none}}
`;
